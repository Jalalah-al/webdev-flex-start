# HTML / CSS / JS PROJECT

## YOUR NAME HERE

## GITHUB REPO ADDRESS

My repo is located at:

https://github.com/YOUR-GITHUB-NAME/YOUR-REPO-NAME

## CONFIRMATION OF FILES

I confirm I have zipped the files in the format of:
├── evidence
│ ├── lighthouse-audits
│ ├── wireframes
├── website_cocde

I confirm I have only included files needed to run the application.

## ADVICE ON SUBMISSION

The `website_code` folder should hold only the files **used** in your project.

Please do not re-submit the `website-images-assets` and `web-site-text-and-data`.  We don't want them back!  It is **LAZY** to include them!
